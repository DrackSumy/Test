GOI PATCH Lockettest / premium4

Cac tep:
- premium4_filter_patch.js: patch Firebase Remote Config, chi giu/nap lai cac filter ID da ton tai trong premium4.
- lockettest_patched.conf: cau hinh Shadowrocket mau, giu 2 rule RevenueCat goc va thay rule premium4 bang script patch.

CACH CAI:
1. Upload premium4_filter_patch.js len mot GitHub repository ban kiem soat.
2. Mo file tren GitHub va lay RAW HTTPS URL.
3. Mo lockettest_patched.conf, thay YOUR_GITHUB_RAW_JS_URL bang URL raw vua lay.
4. Import file .conf vao Shadowrocket.
5. Bat HTTPS MITM cho api.revenuecat.com va firebaseremoteconfig.googleapis.com, cai va tin cay CA cua Shadowrocket tren thiet bi.
6. Thu mo Locket. Neu Remote Config loi, tat rule locket_rc va quay lai cau hinh cu.

GIOI HAN QUAN TRONG:
- premium4 goc da co camera_filter_config va danh sach filter IDs. Patch nay chi ap lai nhom cau hinh do, khong tao engine moi.
- Khong co ma nguon/asset/API duoc xac minh cho Photobooth 2 anh/4 anh, AI model moi, sticker renderer, likeness/create_likeness.
- Shadowrocket chi sua duoc request/response mang; khong the tu them giao dien camera hay code native vao ung dung iOS.
- Chua test tren thiet bi Locket 2.72.1. Khong the cam ket tinh nang hoat dong.
- Patch khong sua RevenueCat va khong tu y chuyen anh/request qua VPS ben thu ba.
